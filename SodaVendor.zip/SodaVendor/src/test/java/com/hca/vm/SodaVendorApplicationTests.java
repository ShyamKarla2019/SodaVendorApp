package com.hca.vm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SodaVendorApplicationTests {

	@Test
	void contextLoads() {
	}

}
