package com.hca.vm.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.hca.vm.form.InventoryForm;
import com.hca.vm.service.InventoryService;

@Controller
public class InventoryAdminCntroller {

	@Autowired
	InventoryService inventoryService;

	// Inject via application.properties
	@Value("${welcome.message}")
	private String message;

	@Value("${error.message}")
	private String errorMessage;

	@RequestMapping(value = { "/", "/index" }, method = RequestMethod.GET)
	public String index(Model model) {

		model.addAttribute("message", message);

		return "index";
	}

	@RequestMapping(value = { "/inventoryList" }, method = RequestMethod.GET)
	public String inventoryList(Model model) {

		model.addAttribute("inventoryList", inventoryService.getInventory());

		return "inventoryList";
	}

	@RequestMapping(value = { "/showAddInventory" }, method = RequestMethod.GET)
	public String showAddInventoryPage(Model model) {

		InventoryForm inventory = new InventoryForm();
		model.addAttribute("inventoryForm", inventory);

		return "showAddInventory";
	}

	@RequestMapping(value = { "/addInventory" }, method = RequestMethod.POST)
	public String saveInventory(Model model, @ModelAttribute("inventoryForm") InventoryForm inventory) {
		String flavour = inventory.getName();
		if (flavour != null && flavour.length() > 0) {
			inventoryService.createInventory(inventory);
			return "redirect:/inventoryList";
		}

		model.addAttribute("errorMessage", errorMessage);
		return "addInventory";
	}
}
