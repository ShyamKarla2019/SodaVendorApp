package com.hca.vm.service;

import java.util.List;

import com.hca.vm.form.InventoryForm;
import com.hca.vm.model.Inventory;

public interface InventoryService {
	public List<Inventory> getInventory();

	public Inventory getInventoryById(String id);

	public void createInventory(InventoryForm inventory);

}
