package com.hca.vm.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hca.vm.form.InventoryForm;
import com.hca.vm.model.Inventory;
import com.hca.vm.repository.InventoryRepository;
import com.hca.vm.service.InventoryService;
@Service
public class InventoryServiceImpl implements InventoryService{
	@Autowired
	InventoryRepository inventoryRepo;
	
	@Override
	public List<Inventory> getInventory() {
		
		return inventoryRepo.findAll();
	}

	@Override
	public Inventory getInventoryById(String id) {
		Optional<Inventory> retrnBean;
		retrnBean=inventoryRepo.findById(Long.parseLong(id));
		return retrnBean.get();
	}

	@Override
	public void createInventory(InventoryForm inventoryForm) {
		Inventory inventory =new Inventory();
		inventory.setName(inventoryForm.getName());
		inventory.setQuantity(inventoryForm.getQuantity());
		inventory.setUnitPrice(inventoryForm.getUnitPrice());
		inventoryRepo.save(inventory);
		
	}
}
