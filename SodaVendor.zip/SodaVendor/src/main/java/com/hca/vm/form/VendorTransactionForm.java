package com.hca.vm.form;

public class VendorTransactionForm {

	private int id;
	private String flavour;
	private Long quarter;
	private Long quarterToReturn;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFlavour() {
		return flavour;
	}

	public void setFlavour(String flavour) {
		this.flavour = flavour;
	}

	public Long getQuarter() {
		return quarter;
	}

	public void setQuarter(Long quarter) {
		this.quarter = quarter;
	}

	public Long getQuarterToReturn() {
		return quarterToReturn;
	}

	public void setQuarterToReturn(Long quarterToReturn) {
		this.quarterToReturn = quarterToReturn;
	}

}
