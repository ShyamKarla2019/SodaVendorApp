package com.hca.vm.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "SodaTransaction")
public class SodaTransaction {

	@Id
	@GeneratedValue
	@Column(name = "id", nullable = false)
	private int id;
	@Column(name = "Flavour", nullable = false)
	private String flavour;
	@Column(name = "Quarter", nullable = false)
	private Long quarter;
	@Column(name = "QuarterToReturn", nullable = false)
	private Long quarterToReturn;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFlavour() {
		return flavour;
	}

	public void setFlavour(String flavour) {
		this.flavour = flavour;
	}

	public Long getQuarter() {
		return quarter;
	}

	public void setQuarter(Long quarter) {
		this.quarter = quarter;
	}

	public Long getQuarterToReturn() {
		return quarterToReturn;
	}

	public void setQuarterToReturn(Long quarterToReturn) {
		this.quarterToReturn = quarterToReturn;
	}

}
