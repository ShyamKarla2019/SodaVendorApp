package com.hca.vm.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hca.vm.model.Inventory;
import com.hca.vm.model.SodaTransaction;
import com.hca.vm.repository.InventoryRepository;
import com.hca.vm.repository.SodaTransactionRepository;
import com.hca.vm.service.VendorService;
@Service
public class VendorServiceImpl  implements VendorService{
	
	@Autowired
	SodaTransactionRepository repo;
	
	@Autowired
	InventoryRepository inventoryRepository;
	@Override
	public String dispense(String flavour,Long quarter) {
		Inventory bean=inventoryRepository.findInventoryByName(flavour);
		if(bean !=null ) {
				if(bean.getQuantity()>0 
				&&  quarter > bean.getUnitPrice()) {
			Long quantity=bean.getQuantity();
			bean.setQuantity(quantity-1);
			inventoryRepository.save(bean);
			
			SodaTransaction sTransacion=new SodaTransaction();
			sTransacion.setFlavour(flavour);
			sTransacion.setQuarter(quarter);
			sTransacion.setQuarterToReturn(quarter-bean.getUnitPrice());
			repo.save(sTransacion);
			return "We are happy to serve you ! Amount to be returned "+sTransacion.getQuarterToReturn();
		}else if(bean.getQuantity() <= 0) {
			return "Flavour you selected is out of stock ";
		}else if(quarter < bean.getUnitPrice()) {
			return "Please insert sufficien Amount ";
		}
		}
		return null;
	}

}
