package com.hca.vm.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hca.vm.model.Inventory;

public interface InventoryRepository extends JpaRepository<Inventory, Long> {

	public Inventory findInventoryByName(String name);

}
