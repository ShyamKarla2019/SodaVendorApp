package com.hca.vm.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hca.vm.model.SodaTransaction;

public interface SodaTransactionRepository extends JpaRepository<SodaTransaction, Long> {

}
