package com.hca.vm.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.hca.vm.form.VendorTransactionForm;
import com.hca.vm.service.VendorService;

@Controller
public class VendorController {

	@Autowired
	VendorService vendorService;

	@Value("${error.message}")
	private String errorMessage;

	@RequestMapping(value = { "/showDispenseSodaView" }, method = RequestMethod.GET)
	public String dispenseSoda(Model model) {

		VendorTransactionForm vendorTransactionForm = new VendorTransactionForm();
		model.addAttribute("vendorTransactionForm", vendorTransactionForm);

		return "showDispenseSodaView";
	}

	@RequestMapping(value = { "/dispenseSoda" }, method = RequestMethod.POST)
	public String dispenseSoda(Model model,
			@ModelAttribute("vendorTransactionForm") VendorTransactionForm vendorTransactionForm) {
		String flavour = vendorTransactionForm.getFlavour();
		Long quarter = vendorTransactionForm.getQuarter();
		if (flavour != null && flavour.length() > 0) {

			String resp = vendorService.dispense(flavour, quarter);
			model.addAttribute("response", resp);
			return "showDispenseSodaView";
		}

		model.addAttribute("errorMessage", errorMessage);
		return "showDispenseSodaView";
	}
}
