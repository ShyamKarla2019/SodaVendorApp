package com.hca.vm.service;

public interface VendorService {

	public String dispense(String flavour, Long quarter);

}
